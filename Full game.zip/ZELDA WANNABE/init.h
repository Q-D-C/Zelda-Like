#ifndef init_h
#define init_h

#include "common.h"

void init_window();

void concierge(void);

SDL_Texture *load_texture(char *filename);

#endif // init_h